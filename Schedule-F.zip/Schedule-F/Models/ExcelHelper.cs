﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Schedule_F
{
    public static class ExcelHelper
    {
        

        public static byte[] ExportToExcel<T>(List<T> list)
        {
            

        int columnCount = 0;

            DateTime StartTime = DateTime.Now;

            StringBuilder rowData = new StringBuilder();

            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

           
            columnCount = 0;
            rowData.Append("<Row ss:Height=\"22\">"); 
            foreach (PropertyInfo p in properties)
            {
                if (p.PropertyType.Name != "EntityCollection`1" && p.PropertyType.Name != "EntityReference`1" && p.PropertyType.Name != p.Name)
                {
                    string columnName = null;

                    var description = p.GetCustomAttribute(typeof(DescriptionAttribute), true);
                    if (description != null)
                        columnName = ((DescriptionAttribute)description).Description;
                    else
                        columnName = p.Name;

                    columnCount++;
                    rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + columnName + "</Data></Cell>");
                }
                else
                    break;

            }
            rowData.Append("</Row>");
        
            foreach (T item in list)
            {
                rowData.Append("<Row>");
                for (int x = 0; x < columnCount; x++) //each (PropertyInfo p in properties)
                {
                    object o = properties[x].GetValue(item, null);
                    string value = o == null ? "" : o.ToString();
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + value + "</Data></Cell>");
               
                }
                rowData.Append("</Row>");
            }

            var sheet = @"<?xml version=""1.0""?>
                    <?mso-application progid=""Excel.Sheet""?>
                    <Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet""
                        xmlns:o=""urn:schemas-microsoft-com:office:office""
                        xmlns:x=""urn:schemas-microsoft-com:office:excel""
                        xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet""
                        xmlns:html=""http://www.w3.org/TR/REC-html40"">
                        <DocumentProperties xmlns=""urn:schemas-microsoft-com:office:office"">
                            <Author>MSADMIN</Author>
                            <LastAuthor>MSADMIN</LastAuthor>
                            <Created>20120-07-03T23:40:11Z</Created>
                            <Company>Microsoft</Company>
                            <Version>12.00</Version>
                        </DocumentProperties>
                        <ExcelWorkbook xmlns=""urn:schemas-microsoft-com:office:excel"">
                            <WindowHeight>6600</WindowHeight>
                            <WindowWidth>12255</WindowWidth>
                            <WindowTopX>240</WindowTopX>
                            <WindowTopY>205</WindowTopY>
                            <ProtectStructure>False</ProtectStructure>
                            <ProtectWindows>False</ProtectWindows>
                        </ExcelWorkbook>
                        <Styles>
                            <Style ss:ID=""Default"" ss:Name=""Normal"">
                                <Alignment ss:Vertical=""Bottom"" />
                                <Borders/>
                                <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""11"" ss:Color=""#000000""/>
                                <Interior/>
                                <NumberFormat/>
                                <Protection/>
                            </Style>
                            <Style ss:ID=""s62"" ss:Name=""Normal 2"">
                               <Alignment ss:Vertical=""Bottom""/>
                               <Borders/>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss""/>
                               <Interior/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                            <Style ss:ID=""s63"" ss:Name=""Normal 3"">
                               <Alignment ss:Vertical=""Bottom""/>
                               <Borders/>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss""/>
                               <Interior/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                            <Style ss:ID=""s64"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000"" ss:Bold=""1""/>
                               <Interior ss:Color=""#C5D9F1"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                            <Style ss:ID=""s65"" ss:Parent=""s63"">
                                <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000"" ss:Bold=""1""/>
                               <Interior ss:Color=""#F2F2F2"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                            </Style>
                            <Style ss:ID=""s66"" ss:Parent=""s63"">
                                <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000""/>
                               <Interior ss:Color=""#F2F2F2"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                            </Style>
                            <Style ss:ID=""s67"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000"" ss:Size=""12"" ss:Bold=""1""/>
                               <Interior ss:Color=""#C5D9F1"" ss:Pattern=""Solid""  />
                               < NumberFormat/>
                               <Protection/>
                              </Style>
                        </Styles>
                        <Worksheet ss:Name=""SchFP3_Regulatory_07062020"">
                            <Table ss:ExpandedColumnCount=""" + (properties.Count() + 1) + @""" ss:ExpandedRowCount=""" + (list.Count() + 1) + @""" x:FullColumns=""1""
                                x:FullRows=""1"" ss:DefaultColumnWidth=""75"" ss:DefaultRowHeight=""15"">
                                " + rowData.ToString() + @"
                            </Table>
                            <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
                                <PageSetup>
                                    <Header x:Margin=""0.3""/>
                                    <Footer x:Margin=""0.3""/>
                                    <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
                                </PageSetup>
                                <Print>
                                    <ValidPrinterInfo/>
                                    <HorizontalResolution>300</HorizontalResolution>
                                    <VerticalResolution>300</VerticalResolution>
                                </Print>
                                <Selected/>
                                <Panes>
                                    <Pane>
                                        <Number>3</Number>
                                        <ActiveCol>2</ActiveCol>
                                    </Pane>
                                </Panes>
                                <ProtectObjects>False</ProtectObjects>
                                <ProtectScenarios>False</ProtectScenarios>
                            </WorksheetOptions>
                        </Worksheet>
                        
                    </Workbook>";

            //<Worksheet ss:Name=""Sheet2"">
            //    <Table ss:ExpandedColumnCount=""1"" ss:ExpandedRowCount=""1"" x:FullColumns=""1""
            //        x:FullRows=""1"" ss:DefaultRowHeight=""15"">
            //    </Table>
            //    <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
            //        <PageSetup>
            //            <Header x:Margin=""0.3""/>
            //            <Footer x:Margin=""0.3""/>
            //            <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
            //        </PageSetup>
            //        <ProtectObjects>False</ProtectObjects>
            //        <ProtectScenarios>False</ProtectScenarios>
            //    </WorksheetOptions>
            //</Worksheet>
            //<Worksheet ss:Name=""Sheet3"">
            //    <Table ss:ExpandedColumnCount=""1"" ss:ExpandedRowCount=""1"" x:FullColumns=""1""
            //        x:FullRows=""1"" ss:DefaultRowHeight=""15"">
            //    </Table>
            //    <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
            //        <PageSetup>
            //            <Header x:Margin=""0.3""/>
            //            <Footer x:Margin=""0.3""/>
            //            <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
            //        </PageSetup>
            //        <ProtectObjects>False</ProtectObjects>
            //        <ProtectScenarios>False</ProtectScenarios>
            //    </WorksheetOptions>
            //</Worksheet>



            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(sheet.ToString());

            return buffer;
        }

        /// <summary>
        /// Extended code for PO line item data export for demand DEM0021331
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        public static void ExportToExcelForMultiInvoiceUpload<T>(List<T> list)
        {
            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            int headerColumnCount = 0;

            int rowCount = 0;

            DateTime StartTime = DateTime.Now;

            StringBuilder rowData = new StringBuilder();

            string[] HeaderColumnName = new string[] { "Supplier ID", "Customer ID", "Customer Company", "Customer VAT ID", "Currency", "Payment Terms", "PO Number", "PO Line Item Number", "Unit", "Quantity", "Net Unit Price", "Sum Exe. VAT", "VAT %", "Sum Incl. VAT", "Description", "Delivery Note", "Product Code", "Material Code", "Tax Juridiction Code", "HSN Code", "SAC Code" };

            rowData.Append("<Row ss:Height=\"39\">");
            foreach (var col in HeaderColumnName)
            {
                headerColumnCount++;
                rowData.Append("<Cell ss:StyleID=\"s64\"><Data ss:Type=\"String\">" + col + "</Data></Cell>");
            }
            rowData.Append("</Row>");

            foreach (T item in list)
            {
                var purchaseOrder = item.GetType();
                var lineItems = (IList)purchaseOrder.GetProperty("LineItems").GetValue(item);

                foreach (var lineItem in lineItems)
                {
                    var poItem = lineItem.GetType();
                    rowData.Append("<Row>");
                    var Supplier = purchaseOrder.GetProperty("Supplier").GetValue(item);
                    rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + Supplier.GetType().GetProperty("SapSupplierId").GetValue(Supplier).ToString() + "</Data></Cell>");
                    var company = purchaseOrder.GetProperty("Company").GetValue(item);
                    rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + company.GetType().GetProperty("SapId").GetValue(company).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + company.GetType().GetProperty("Name").GetValue(company).ToString() + "</Data></Cell>");
                    if (purchaseOrder.GetProperty("CompanyVATNumber").GetValue(item) != null)
                        rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + purchaseOrder.GetProperty("CompanyVATNumber").GetValue(item) + "</Data></Cell>");
                    else
                        rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + string.Empty + "</Data></Cell>");

                    rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + purchaseOrder.GetProperty("Currency").GetValue(item).ToString() + "</Data></Cell>");
                    var paymentTerm = purchaseOrder.GetProperty("PaymentTerm").GetValue(item);
                    rowData.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + paymentTerm.GetType().GetProperty("Term").GetValue(paymentTerm).ToString() + "</Data></Cell>");

                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("PONumber").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("POLineItemNumber").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("UnitOfMeasureCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("Quantity").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("UnitPrice").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("TotalAmount").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + Convert.ToString(poItem.GetProperty("VatPercentage").GetValue(lineItem)) + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + string.Empty + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("Description").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + string.Empty + "</Data></Cell>");
                    rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + string.Empty + "</Data></Cell>");
                    var matCode = poItem.GetProperty("MaterialCode").GetValue(lineItem);

                    if (matCode != null)
                        rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("MaterialCode").GetValue(lineItem) + "</Data></Cell>");
                    else
                        rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + string.Empty + "</Data></Cell>");


                    var taxjurcode = poItem.GetProperty("TaxJurCode").GetValue(lineItem);
                    var hsncode = poItem.GetProperty("HsnCode").GetValue(lineItem);
                    var saccode = poItem.GetProperty("SacCode").GetValue(lineItem);

                    if (taxjurcode != null)
                        rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("TaxJurCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    else
                        rowData.Append("<Cell ss:StyleID=\"s66\"/>");

                    if (hsncode != null)
                    {
                        rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("HsnCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    }
                    else
                    {
                        rowData.Append("<Cell ss:StyleID=\"s66\"/>");
                    }

                    if (saccode != null)
                    {
                        rowData.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("SacCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    }
                    else
                    {
                        rowData.Append("<Cell ss:StyleID=\"s66\"/>");
                    }



                    rowData.Append("</Row>");
                    rowCount++;
                }
            }
            rowCount++;

            //Multi-upload data sheet
            PropertyInfo[] properties_multi = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            int headerColumnCount_multi = 0;
            int itemColumnCount_multi = 0;
            int rowCount_multi = 0;

            DateTime StartTime1 = DateTime.Now;

            StringBuilder rowData_multi = new StringBuilder();

            string[] HeaderColumnName_multi = new string[] { "Header", "Invoice Type", "Supplier ID", "Supplier company VAT reg. no", "Bank Account", "Customer ID", "VAT ID", "Invoice No", "Invoice Date", "Invoice Amount", "Currency", "Payment terms", "Due Date", "Payment reference No", "Customer contact name", "Customer contact email", "Original invoice no" };
            string[] ItemColumnName_multi = new string[] { "Line", "PO Number", "PO Line Item Number", "Unit", "Quantity", "Net unit price", "Sum exc. VAT", "VAT %", "Sum incl. VAT", "Description", "Delivery note", "Supplier product code", "Customer Material code", "Cost Center Code", "WBS Element Code", "GL Account", "Material or service", "Tax Juridiction Code", "HSN Code", "SAC Code", "Shipped from", "Shipped to", "Ref. PO number", "AWBN", "SRN NUMBER" };


            rowData_multi.Append("<Row ss:Height=\"39\">");
            foreach (var col in HeaderColumnName_multi)
            {
                headerColumnCount_multi++;
                rowData_multi.Append("<Cell ss:StyleID=\"s64\"><Data ss:Type=\"String\">" + col + "</Data></Cell>");
            }
            rowData_multi.Append("</Row>");

            rowData_multi.Append("<Row ss:Height=\"39\">");
            foreach (var col in ItemColumnName_multi)
            {
                itemColumnCount_multi++;
                rowData_multi.Append("<Cell ss:StyleID=\"s65\"><Data ss:Type=\"String\">" + col + "</Data></Cell>");
            }
            rowData_multi.Append("</Row>");

            foreach (T item in list)
            {
                var purchaseOrder = item.GetType();
                rowData_multi.Append("<Row>");
                rowData_multi.Append("<Cell ss:StyleID=\"s64\"><Data ss:Type=\"String\">" + "1" + "</Data></Cell>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");

                var company = purchaseOrder.GetProperty("Company").GetValue(item);

                rowData_multi.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + company.GetType().GetProperty("SapId").GetValue(company).ToString() + "</Data></Cell>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + purchaseOrder.GetProperty("Currency").GetValue(item).ToString() + "</Data></Cell>");

                var paymentTerm = purchaseOrder.GetProperty("PaymentTerm").GetValue(item);

                rowData_multi.Append("<Cell ss:StyleID=\"s67\"><Data ss:Type=\"String\">" + paymentTerm.GetType().GetProperty("Term").GetValue(paymentTerm).ToString() + "</Data></Cell>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("<Cell ss:StyleID=\"s67\"/>");
                rowData_multi.Append("</Row>");

                var lineItems = (IList)purchaseOrder.GetProperty("LineItems").GetValue(item);
                foreach (var lineItem in lineItems)
                {
                    var poItem = lineItem.GetType();
                    rowData_multi.Append("<Row>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s65\"><Data ss:Type=\"String\">" + "2" + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("PONumber").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("POLineItemNumber").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("UnitOfMeasureCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("Quantity").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("UnitPrice").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("TotalAmount").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + Convert.ToString(poItem.GetProperty("VatPercentage").GetValue(lineItem)) + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("Description").GetValue(lineItem).ToString() + "</Data></Cell>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    var matCode = poItem.GetProperty("MaterialCode").GetValue(lineItem);

                    if (matCode != null)
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("MaterialCode").GetValue(lineItem) + "</Data></Cell>");
                    else
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");


                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");

                    var taxjurcode = poItem.GetProperty("TaxJurCode").GetValue(lineItem);
                    var hsncode = poItem.GetProperty("HsnCode").GetValue(lineItem);
                    var saccode = poItem.GetProperty("SacCode").GetValue(lineItem);

                    if (taxjurcode != null)
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("TaxJurCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    else
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");

                    if (hsncode != null)
                    {
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("HsnCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    }
                    else
                    {
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    }

                    if (saccode != null)
                    {
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"><Data ss:Type=\"String\">" + poItem.GetProperty("SacCode").GetValue(lineItem).ToString() + "</Data></Cell>");
                    }
                    else
                    {
                        rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    }


                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("<Cell ss:StyleID=\"s66\"/>");
                    rowData_multi.Append("</Row>");
                    rowCount_multi++;
                }
            }

            rowCount_multi++;

            var sheet = @"<?xml version=""1.0""?>
                    <?mso-application progid=""Excel.Sheet""?>
                    <Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet""
                        xmlns:o=""urn:schemas-microsoft-com:office:office""
                        xmlns:x=""urn:schemas-microsoft-com:office:excel""
                        xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet""
                        xmlns:html=""http://www.w3.org/TR/REC-html40"">
                        <DocumentProperties xmlns=""urn:schemas-microsoft-com:office:office"">
                            <Title>1001</Title>
                            <Author>MSADMIN</Author>
                            <LastAuthor>MSADMIN</LastAuthor>
                            <Created>2011-07-12T23:40:11Z</Created>
                            <Company>Microsoft</Company>
                            <Version>12.00</Version>
                        </DocumentProperties>
                        <ExcelWorkbook xmlns=""urn:schemas-microsoft-com:office:excel"">
                            <WindowHeight>6210</WindowHeight>
                            <WindowWidth>17235</WindowWidth>
                            <WindowTopX>240</WindowTopX>
                            <WindowTopY>105</WindowTopY>
                            <ProtectStructure>False</ProtectStructure>
                            <ProtectWindows>False</ProtectWindows>
                        </ExcelWorkbook>
                        <Styles>
                            <Style ss:ID=""Default"" ss:Name=""Normal"">
                                <Alignment ss:Vertical=""Bottom""/>
                                <Borders/>
                                <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""8"" ss:Color=""#000000""/>
                                <Interior/>
                                <NumberFormat/>
                                <Protection/>
                            </Style>
                            <Style ss:ID=""s62"" ss:Name=""Normal 2"">
                               <Alignment ss:Vertical=""Bottom""/>
                               <Borders/>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss""/>
                               <Interior/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                            <Style ss:ID=""s63"" ss:Name=""Normal 3"">
                               <Alignment ss:Vertical=""Bottom""/>
                               <Borders/>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss""/>
                               <Interior/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                            <Style ss:ID=""s64"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000"" ss:Bold=""1""/>
                               <Interior ss:Color=""#C5D9F1"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                            <Style ss:ID=""s65"" ss:Parent=""s63"">
                                <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000"" ss:Bold=""1""/>
                               <Interior ss:Color=""#F2F2F2"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                            </Style>
                            <Style ss:ID=""s66"" ss:Parent=""s63"">
                                <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000""/>
                               <Interior ss:Color=""#F2F2F2"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                            </Style>
                            <Style ss:ID=""s67"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Center"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Color=""#000000"" />
                               <Interior ss:Color=""#C5D9F1"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                        </Styles>
                        <Worksheet ss:Name=""Reporting"">
                            <Table ss:ExpandedColumnCount=""" + (headerColumnCount + 1) + @""" ss:ExpandedRowCount=""" + (10000) + @""" x:FullColumns=""1""
                                x:FullRows=""1"" ss:DefaultColumnWidth=""75"" ss:DefaultRowHeight=""15"">
                                " + rowData.ToString() + @"
                            </Table>
                            <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
                                <PageSetup>
                                    <Header x:Margin=""0.3""/>
                                    <Footer x:Margin=""0.3""/>
                                    <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
                                </PageSetup>
                                <Print>
                                    <ValidPrinterInfo/>
                                    <HorizontalResolution>300</HorizontalResolution>
                                    <VerticalResolution>300</VerticalResolution>
                                </Print>
                                <Selected/>
                                <Panes>
                                    <Pane>
                                        <Number>3</Number>
                                        <ActiveCol>2</ActiveCol>
                                    </Pane>
                                </Panes>
                                <ProtectObjects>False</ProtectObjects>
                                <ProtectScenarios>False</ProtectScenarios>
                            </WorksheetOptions>
                        </Worksheet>
                        <Worksheet ss:Name=""PO Form for multi-upload"">
                            <Table ss:ExpandedColumnCount=""" + (itemColumnCount_multi + 1) + @""" ss:ExpandedRowCount=""" + (10000) + @""" x:FullColumns=""1""
                                x:FullRows=""1"" ss:DefaultColumnWidth=""75"" ss:DefaultRowHeight=""15"">
                                " + rowData_multi.ToString() + @"
                            </Table>
                            <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
                                <PageSetup>
                                    <Header x:Margin=""0.3""/>
                                    <Footer x:Margin=""0.3""/>
                                    <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
                                </PageSetup>
                                <ProtectObjects>False</ProtectObjects>
                                <ProtectScenarios>False</ProtectScenarios>
                            </WorksheetOptions>
                        </Worksheet>
                        <Worksheet ss:Name=""Sheet3"">
                            <Table ss:ExpandedColumnCount=""1"" ss:ExpandedRowCount=""1"" x:FullColumns=""1""
                                x:FullRows=""1"" ss:DefaultRowHeight=""15"">
                            </Table>
                            <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
                                <PageSetup>
                                    <Header x:Margin=""0.3""/>
                                    <Footer x:Margin=""0.3""/>
                                    <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
                                </PageSetup>
                                <ProtectObjects>False</ProtectObjects>
                                <ProtectScenarios>False</ProtectScenarios>
                            </WorksheetOptions>
                        </Worksheet>
                    </Workbook>";

            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(sheet.ToString());

            //return buffer;//Change the return type to buffer

            //System.Diagnostics.Debug.Print(StartTime.ToString() + " - " + DateTime.Now);
            //System.Diagnostics.Debug.Print((DateTime.Now - StartTime).ToString());

            //HttpContext.Current.Response.ClearContent();
            //HttpContext.Current.Response.Write(sheet);

            //string filename = string.Format("{0}.xls", DateTime.UtcNow.ToString("yyyyMMddHHmm"));

            //HttpContext.Current.Response.ContentType = "application/ms-excel";

            //HttpContext.Current.Response.AddHeader("Content-Disposition", "Attachment;Filename=" + filename);

            //HttpContext.Current.Response.End();
        }
        /// <summary>
        /// Below function is created by Kiran K for Survey Report
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        public static void ExportToExcelForSurveyData<T>(List<T> list)
        {
            try
            {
                PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                int rowCount = 0;
                DateTime StartTime = DateTime.Now;
                StringBuilder SurveyData = new StringBuilder();
                StringBuilder SurveyReportData = new StringBuilder();

                string[] HeaderRptColumnName = new string[] { "Survey Instance ID", "Survey Recording Date", "Question", "Selected Answers/Options", "Free Text Answer" };

                SurveyReportData.Append("<Row ss:Height=\"39\">");

                foreach (var col in HeaderRptColumnName)
                {
                    SurveyReportData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">" + col + "</Data></Cell>");
                }
                SurveyReportData.Append("</Row>");

                foreach (T item in list)
                {
                    var surveydetails = item.GetType();
                    //survey data
                    if (rowCount < 1)
                    {
                        SurveyData.Append("<Row>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">Survey ID</Data></Cell>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurdata\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("Surveyid").GetValue(item) + "</Data></Cell>");

                        SurveyData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\"></Data></Cell>");

                        SurveyData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">CreatedBy</Data></Cell>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurdata\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("CreatedBy").GetValue(item) + "</Data></Cell>");
                        SurveyData.Append("</Row>");

                        SurveyData.Append("<Row>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">Survey Name</Data></Cell>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurdata\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("SurveyName").GetValue(item) + "</Data></Cell>");

                        SurveyData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\"></Data></Cell>");

                        SurveyData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">ApplicationName</Data></Cell>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurdata\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("ApplicationName").GetValue(item) + "</Data></Cell>");
                        SurveyData.Append("</Row>");

                        SurveyData.Append("<Row>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">Survey StartDate</Data></Cell>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurdata\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("StartDate").GetValue(item) + "</Data></Cell>");

                        SurveyData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\"></Data></Cell>");

                        SurveyData.Append("<Cell ss:StyleID=\"ssurlbl\"><Data ss:Type=\"String\">Survey EndDate</Data></Cell>");
                        SurveyData.Append("<Cell ss:StyleID=\"ssurdata\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("EndDate").GetValue(item) + "</Data></Cell>");

                        SurveyData.Append("</Row>");

                        SurveyData.Append("<Row>");
                        SurveyData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\"></Data></Cell>");
                        SurveyData.Append("</Row>");
                    }

                    //Report data
                    SurveyReportData.Append("<Row>");

                    SurveyReportData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("SurveyInstanceID").GetValue(item) + "</Data></Cell>");
                    SurveyReportData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("SurveyRecordingDate").GetValue(item) + "</Data></Cell>");
                    SurveyReportData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("Question").GetValue(item) + "</Data></Cell>");
                    SurveyReportData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("Answers").GetValue(item) + "</Data></Cell>");
                    SurveyReportData.Append("<Cell ss:StyleID=\"semtcell\"><Data ss:Type=\"String\">" + surveydetails.GetProperty("UsersFreeTextData").GetValue(item) + "</Data></Cell>");

                    SurveyReportData.Append("</Row>");

                    rowCount++;
                }

                var sheet = @"<?xml version=""1.0""?>
                    <?mso-application progid=""Excel.Sheet""?>
                    <Workbook xmlns=""urn:schemas-microsoft-com:office:spreadsheet""
                        xmlns:o=""urn:schemas-microsoft-com:office:office""
                        xmlns:x=""urn:schemas-microsoft-com:office:excel""
                        xmlns:ss=""urn:schemas-microsoft-com:office:spreadsheet""
                        xmlns:html=""http://www.w3.org/TR/REC-html40"">
                        <DocumentProperties xmlns=""urn:schemas-microsoft-com:office:office"">
                            <Title>1001</Title>
                            <Author>MSADMIN</Author>
                            <LastAuthor>MSADMIN</LastAuthor>
                            <Created>2011-07-12T23:40:11Z</Created>
                            <Company>Microsoft</Company>
                            <Version>12.00</Version>
                        </DocumentProperties>
                        <ExcelWorkbook xmlns=""urn:schemas-microsoft-com:office:excel"">
                            <WindowHeight>6210</WindowHeight>
                            <WindowWidth>17235</WindowWidth>
                            <WindowTopX>240</WindowTopX>
                            <WindowTopY>105</WindowTopY>
                            <ProtectStructure>False</ProtectStructure>
                            <ProtectWindows>False</ProtectWindows>
                        </ExcelWorkbook>
                        <Styles>
                            <Style ss:ID=""Default"" ss:Name=""Normal"">
                                <Alignment ss:Vertical=""Bottom""/>
                                <Borders/>
                                <Font ss:FontName=""Calibri"" x:Family=""Swiss"" ss:Size=""8"" ss:Color=""#000000""/>
                                <Interior/>
                                <NumberFormat/>
                                <Protection/>
                            </Style>
                            <Style ss:ID=""s62"" ss:Name=""Normal 2"">
                               <Alignment ss:Vertical=""Bottom""/>
                               <Borders/>
                               <Font ss:FontName=""Calibri"" x:Family=""Swiss""/>
                               <Interior/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                              <Style ss:ID=""ssurlbl"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Left"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Arial""  ss:FontSize=""10""  x:Family=""Swiss"" ss:Color=""#000000""  ss:Bold=""1""/>
                               <Interior ss:Color=""#d6d6d6"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                              <Style ss:ID=""ssurdata"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Left"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""2""/>
                               </Borders>
                               <Font ss:FontName=""Arial""  ss:FontSize=""10"" x:Family=""Swiss"" ss:Color=""#000000""  ss:Bold=""1""/>
                               <Interior ss:Color=""#eeee00"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                              <Style ss:ID=""semtcell"" ss:Parent=""s62"">
                               <Alignment ss:Horizontal=""Left"" ss:Vertical=""Bottom"" ss:WrapText=""1""/>
                               <Borders>
                                <Border ss:Position=""Bottom"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Left"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Right"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                                <Border ss:Position=""Top"" ss:LineStyle=""Continuous"" ss:Weight=""1""/>
                               </Borders>
                               <Font ss:FontName=""Arial""  ss:FontSize=""10"" x:Family=""Swiss"" ss:Color=""#000000""  ss:Bold=""1""/>
                               <Interior ss:Color=""#ffffff"" ss:Pattern=""Solid""/>
                               <NumberFormat/>
                               <Protection/>
                              </Style>
                        </Styles>
                        <Worksheet ss:Name=""SurveyData"">
                            <Table ss:ExpandedColumnCount=""" + (6 + 1) + @""" ss:ExpandedRowCount=""" + (10000) + @""" x:FullColumns=""1""
                                x:FullRows=""1"" ss:DefaultColumnWidth=""120"" ss:DefaultRowHeight=""15"">
                                " + SurveyData.ToString() + SurveyReportData.ToString() + @"
                            </Table>
                           <WorksheetOptions xmlns=""urn:schemas-microsoft-com:office:excel"">
                                <PageSetup>
                                    <Header x:Margin=""0.3""/>
                                    <Footer x:Margin=""0.3""/>
                                    <PageMargins x:Bottom=""0.75"" x:Left=""0.7"" x:Right=""0.7"" x:Top=""0.75""/>
                                </PageSetup>
                                <Print>
                                    <ValidPrinterInfo/>
                                    <HorizontalResolution>300</HorizontalResolution>
                                    <VerticalResolution>300</VerticalResolution>
                                </Print>
                                <Selected/>
                                <Panes>
                                    <Pane>
                                        <Number>3</Number>
                                        <ActiveCol>2</ActiveCol>
                                    </Pane>
                                </Panes>
                                <ProtectObjects>False</ProtectObjects>
                                <ProtectScenarios>False</ProtectScenarios>
                            </WorksheetOptions>
                        </Worksheet>
                    </Workbook>";


                //HttpContext.Current.Response.ClearContent();
                //HttpContext.Current.Response.Write(sheet);
                //SurveyData.Length = 0;
                //SurveyReportData.Length = 0;

                //string filename = string.Format("{0}.xls", DateTime.UtcNow.ToString("yyyyMMddHHmm"));

                //HttpContext.Current.Response.ContentType = "application/ms-excel";

                //HttpContext.Current.Response.AddHeader("Content-Disposition", "Attachment;Filename=" + filename);

                //HttpContext.Current.Response.End();
            }
            catch (Exception ex)
            {
                //FileLog log = new FileLog();
                //log.WriteException("ExcelHelper", "Survey Export2Excel failed: " + ex.Message + " st:" + ex.StackTrace);
            }

        }
    }
}
