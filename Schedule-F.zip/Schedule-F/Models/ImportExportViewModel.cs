﻿using EntiryModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Schedule_F.Models
{
    public class ImportExportViewModel
    {
        public bool accessDB { get; set; }
        public bool accessDBTemplate { get; set; }
        public bool accessDBTemplateYes { get; set; }
        public bool accessDBTemplateNo { get; set; }
        public List<SelectListItem> CompanyDetails { get; set; }
        public string CompanyName { get; set; }

        public bool ceded { get; set; }
        public bool assumed { get; set; }
        public bool exportFVStaged { get; set; }
        public bool sourceCodeProvided { get; set; }
        public List<SelectListItem> Tables { get; set; }
        
        public string SelectedTable { get; set; }
        
        public IFormFile fileUpload { get; set; }
        public string Message { get; set; }
        public string fileName { get; set; }
        public string IsFileUploaded { get; set; }
        public ErrorDetails errorDetails  { get; set; }
        public ImportMessage processRecord { get; set; }
        public ImportExportViewModel()
        {
            CompanyDetails = new List<SelectListItem>();
            accessDB = true;
            accessDBTemplateYes = true;
        }
        public List<SelectListItem> GetCompanyList(IEnumerable<CompanyGroup> companyDetails)
        {
            var lstCompanyGroups = new List<SelectListItem>();
            SelectListItem lstCompanyGroup = null;
                
            foreach (CompanyGroup companyDetail in companyDetails)
            {
                lstCompanyGroup = new SelectListItem() {Value= companyDetail.GroupCdSuper_int.ToString(), Text = companyDetail.GroupCdSuperName};
                lstCompanyGroups.Add(lstCompanyGroup);
            }
            return lstCompanyGroups;
        }
        
    }

    public class ImportMessage
    {
        public string ProcessedRecord { get; set; }
        public string AppliedRecord { get; set; }
        public string RejectedRecord { get; set; }
    }
}
