﻿using EntiryModel;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Schedule_F.Models
{
    public class ContactViewModel
    {
        [Display(Name = "Reinsurer Code")]
        [RegularExpression(@"^.{3,}$", ErrorMessage = "Minimum 3 characters required for name.")]
        [Required(ErrorMessage = "Required")]
        [StringLength(20, MinimumLength = 3, ErrorMessage = "Maximum 30 characters in name.")]
        public string ReinsurerCode { get; set; }

        public string MyItem { get; set; }
        public List<SelectListItem> MyItems { get; set; }
        public List<Reinsurer> Reinsurer { get; set; }
        public string NoRecordMessage { get; set; }
        public ContactViewModel()
        {
            MyItems = GetContactCategory();
            MyItem = "13";

        }
        public List<SelectListItem> GetContactCategory()
        {
            var contactCategory = new List<SelectListItem>()
            {
                 new SelectListItem { Value = "0", Text = "Batch Code" },
                 new SelectListItem { Value = "1",Text = "Batch Name" },
                 new SelectListItem { Value = "2",Text = "Broker Code" },
                 new SelectListItem { Value = "3",Text = "BBroker Name" },
                 new SelectListItem { Value = "4", Text = "Collateral Control Number" },
                 new SelectListItem { Value = "5", Text = "Contract Code" },
                 new SelectListItem { Value = "6", Text = "Contract Name" },
                 new SelectListItem { Value = "7", Text = "Federal ID" },
                 new SelectListItem { Value = "8", Text = "Former Reinsurer Code" },
                 new SelectListItem { Value = "9", Text = "Former Contract Code" },
                 new SelectListItem { Value = "10", Text = "Letter Of Credit Number" },
                 new SelectListItem { Value = "11", Text = "NAIC Code" },
                 new SelectListItem { Value = "12", Text = "Reinsurer Alias" },
                 new SelectListItem { Value = "13", Text = "Reinsurer Code" },
                 new SelectListItem { Value = "14", Text = "Reinsurer Name" },
                 new SelectListItem { Value = "15", Text = "Reinsurer Rollup Code" },
                 new SelectListItem { Value = "16", Text = "Reporting Code" },
                 new SelectListItem { Value = "17", Text = "Reporting Name" },
                 new SelectListItem { Value = "18", Text = "Treaty Code" }
            };
            return contactCategory;
        }

        public string GetLookInCode(int searchCode)
        {
            string result = string.Empty;
            switch (searchCode)
            {
                case 7:
                    {
                        result = "fein";
                        break;
                    }
                case 8:
                    {
                        result = "former";
                        break;
                    }
                case 11:
                    {
                        result =  "naic";
                        break;
                    }
                case 12:
                    {
                        result = "alias";
                        break;
                    }

                case 13:
                    {
                        result = "code";
                        break;
                    }

                case 14:
                    {
                        result = "name";
                        break;
                    }

                case 15:
                    {
                        result = string.Empty; //"rpting";
                        break;
                    }
                // Changes Start - Included Reporting code and Reporting name options for defect PRB0500823
                case 16:
                    {
                        result =  "rpting code";
                        break;
                    }

                case 17:
                    {
                        result = "rpting name";
                        break;
                    }

                    // Changes End - Included Reporting code and Reporting name options for defect PRB0500823
            }
            return result;
        }
    }
}
