﻿using EntiryModel;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace Schedule_F.Models
{
    public class ReportsViewModel 
    {
        //Fetches Category List
        public List<SelectListItem> Category { get; set; }

        public List<SelectListItem> lstCategory( IEnumerable<EntiryModel.ReportIdentification> list)
        {
           // List<SelectListItem> lstItem = new List<SelectListItem>();

            return list.Select(pt => new SelectListItem
            {
                Value = pt.SubCategory,
                Text = pt.SubCategory
            }).ToList();


        }

        public List<SelectListItem> lstCompany(IEnumerable<EntiryModel.CompanyCode> list)
        {
            // List<SelectListItem> lstItem = new List<SelectListItem>();

            return list.Select(lst => new SelectListItem
            {
                Value = lst.ComCode,
                Text = lst.Name
            }).ToList();


        }

        public List<SelectListItem> rptName { get; set; }
        public List<SelectListItem> rptNameLst(IEnumerable<EntiryModel.ReportIdentification> list)
        {

            return list.Select(pt => new SelectListItem
            {
                Value = pt.ReportID,
                Text = pt.Name
            }).ToList();


            //List<ReportIdentification> lstRptIdentification = new List<ReportIdentification>();
           

            //foreach (var lstitem in list)
            //{
            //    ReportIdentification rptIdentification = new ReportIdentification();

            //    rptIdentification.ReportID = lstitem.ReportID;
            //    rptIdentification.Name = lstitem.Name;
            //    rptIdentification.Description = lstitem.Description;
            //    rptIdentification.FileName = lstitem.FileName;
            //    rptIdentification.StoredProcName = lstitem.StoredProcName;

            //    lstRptIdentification.Add(rptIdentification);
            //}

            //return list.Select(lst => new ReportIdentification
            // {
            //     ReportID = lst.ReportID,
            //     Name = lst.Name,
            //     Description = lst.Description,
            //     FileName = lst.FileName,
            //     StoredProcName= lst.StoredProcName
            // }).ToList();
            //return lstRptIdentification.ToList();
        }

        public List<SelectListItem> lstfinStatus(IEnumerable<EntiryModel.FinancialStatus> list)
        {
            // List<SelectListItem> lstItem = new List<SelectListItem>();

            return list.Select(lst => new SelectListItem
            {
                Value = lst.FinancialStatusCode,
                Text = lst.Description
            }).ToList();


        }

        public List<SelectListItem> lstLocation(IEnumerable<EntiryModel.Location> list)
        {
            // List<SelectListItem> lstItem = new List<SelectListItem>();

            return list.Select(lst => new SelectListItem
            {
                Value = lst.LocationCode,
                Text = lst.Description
            }).ToList();


        }

        public IEnumerable<EntiryModel.ReportCriteria> LstReportCriteria(IEnumerable<EntiryModel.ReportCriteria> list)
        {
            return list.Select(lst => new EntiryModel.ReportCriteria
            {
                ParmID= lst.ParmID,
                ParmMaxAllowed= lst.ParmMaxAllowed,
                ParmOrder= lst.ParmOrder,
                ReportID=lst.ReportID

            }).ToList();
        }

        public List<SelectListItem> finStatus { get; set; }

        public List<SelectListItem> Company { get; set; }

        public List<SelectListItem> location { get; set; }

        public string txtArea { get; set; }
    }
}
