﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule_F.Models
{
    public class ExcelHeader
    {

        public StringBuilder GetHeader()
        {
            StringBuilder header = new StringBuilder();
            header.Append("[SectionName]");
            header.Append("[SectionID]");
            header.Append("[ReinsurerCode]");
      
            header.Append("[DetailTotalFlag]");

            header.Append("[Federal ID Number(1)]");
            header.Append("[NAIC Company Code(2)]");
            header.Append("[Reinsurer Name(3)]");
            header.Append("[Domicile(4)]");
            header.Append("[Special Code(5)]");
            header.Append("[Reinsurance Premiums Ceded(6)]");
            header.Append("[Paid Losses(7)]");
            header.Append("[Paid LAE(8)]");
            header.Append("[Known Case Loss Reserves(9)]"); 
            header.Append("[Known Case LAE Reserves(10)]"); 
            header.Append("[IBNR Loss Reserves(11)]");
            header.Append("[IBNR LAE Reserves(12)]");
            header.Append("[Unearned Premiums(13)]");
            header.Append("[Contingent Commissions(14)]");
            header.Append("[Col 7 thru 14 Totals(15)]");
            header.Append("[Amt in Disp from Column 15(16)]");
            header.Append("[Ceded Balances Payable(17)]");
            header.Append("[Other Amts Due to Reco(18)]");
            header.Append("[Net Amt Recoverable - Reco(19)]");
            header.Append("[Funds Held Reco Treaty(20)]");
            header.Append("[Multiple Beneficiary Trust(21)]");
            header.Append("[Letters Of Credit(22)]");
            header.Append("[Issuing Bank Ref Num(23)] ");
            header.Append("[Trusts &Other Collateral(24)]");
            header.Append("[Total Funds Held(25)]");
            header.Append("[Net Recov(Col  15 - 25)(26)]");
            header.Append("[Applicable Sch  F Penalty(27)]");
            header.Append("[Total Recov(Cols 15 - 27)(28)]");
            header.Append("[Stressed Recov(Col28 * 120 %)(29)]");
            header.Append("[Reins Payable &Funds Held(30)]");
            header.Append("[Stressed Net Recov(31)]");
            header.Append("[Total Collateral(32)]");
            header.Append("[Stressed Net Recov(33)]");
            header.Append("[Reco DesignationEquivalent(34)]");
            header.Append("[CreditRisk-Collateral(35)]");
            header.Append("[CreditRisk-Uncollateral(36)]");
            header.Append("[Overdue Current(37)]");
            header.Append("[Overdue 1 to 29 Days(38)]");
            header.Append("[Overdue 30 to 90 Days(39)]");
            header.Append("[Overdue 91 to 120 Days(40)]");
            header.Append("[Overdue Over 120 Days(41)]");
            header.Append("[Total Overdue(42)]");
            header.Append("[Total Due(Cols  37 + 42)(43)]");
            header.Append("[Total Recov Disp in Col 43(44)]");
            header.Append("[Col 45 Amt(45)]");
            header.Append("[Cols 43 - Col 44(46)]");
            header.Append("[(Cols  40 + 41 - 45)(47)]");
            header.Append("[Amt Received Prior 90 Days(48)]");
            header.Append("[% Overdue Col 42 Col 43(49)]");
            header.Append("[(Col  47  Cols  46 + 48)(50)]");
            header.Append("[% > 120DaysOverdue(41 43)(51)]");
            header.Append("[Amount in Col 50 < 20 % (52)]");
            header.Append("[Col 47 < 20 % in Col50(53)]");
            header.Append("[Certified Reinsurer Rating(54)]");
            header.Append("[Certified Reco Eff Date(55)]");
            header.Append("[Certified Percent(56)]");
            header.Append("[Catastrophe Recoverables(57)]"); 
            header.Append("[Net Recov(Col 19 - Col 57)(58)]");
            header.Append("[Collateral Req(Cols56 * 58)(59)]");
            header.Append("[(Col 25 Col 58)(60)]");
            header.Append("[Col60 Col56 nt exceed 100 % (61)]");
            header.Append("[(Col  45 * 20 %)(62)]");
            header.Append("[(Col 57 + Col 58 * Col 61)(63)]");
            header.Append("[(Col  19 - Col  63)(64)]");
            header.Append("[(Col  47 * 20 %)(65)]");
            header.Append("[(Col 25 not Exceed Col 63)(66)]");
            header.Append("[(Col 63 - Col 66)(67)]");
            header.Append("[20 % of Amount in Col  67(68)] ");
            header.Append("[Col 69] ");
            header.Append("[Col  47 * 20 % (70)]");
            header.Append("[Reins Unauthorized Reco(71)] ");
            header.Append("[(Col  70 + 20 % of Col  16)(72)]");
            header.Append("[Col 73 Amount]");
            header.Append("[COl 74 Amount]");
            header.Append("[Ceded to Authorized Reco(75)]");
            header.Append("[Ceded to Unauthorized Reco(76)]");
            header.Append("[Ceded to Certified Reco(77)]");
            header.Append("[Total(Cols  75 + 76 + 77)(78)]");
            header.Append("[CompanyName]");
            header.Append("[LocationName]");
            header.Append("[ProcessPeriod]");
            return header;
        }
    }
}
