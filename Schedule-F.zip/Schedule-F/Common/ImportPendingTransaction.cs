﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using DataAccess;
using DataAccess.MsAccess;
using EntiryModel;
using Schedule_F.Models;

namespace Schedule_F.Common
{
    public class ImportPendingTransaction
    {
        private readonly IImportExportRepository _importExportRepository;
        private readonly IMsAccessDataRepository _iMsAccessDataRepository;
        bool lbError = false;
        public ImportPendingTransaction(IImportExportRepository importExportRepository, IMsAccessDataRepository iMsAccessDataRepository)
        {

            _importExportRepository = importExportRepository;
            _iMsAccessDataRepository = iMsAccessDataRepository;
        }

        
        public ImportExportViewModel Import(ImportExportViewModel viewModel, string tableName, string fileLocation)
        {
            // check in AccessDb or AccessDB template
            if(viewModel.accessDB)
            {
                viewModel = ImportPending(viewModel, tableName, fileLocation);

            }
            else
            {
                viewModel = ImportPendingManuals(viewModel, tableName, fileLocation);
            }
            return viewModel;
        }
        public ImportExportViewModel ImportPending(ImportExportViewModel viewModel, string tableName, string fileLocation)
        {
            var lsErrDesc = default(string);           
            int llTranAmt;
            // Initilize Error Log
            var logTableCreation = _iMsAccessDataRepository.InitializeErrorLog(tableName, fileLocation);
            // Get closeDate 
            var closeDate = _importExportRepository.GetCloseDate();
            //Load table data 
            List<PendingTransaction> loPendingTrans = null;
            List<string> tables = new List<string>();
            if (tableName != null)
            {
                if (tableName.IndexOf(',') > 0)
                    tables = tableName.Split(",").ToList();
                else tables.Add(tableName);
                foreach (string table in tables)
                {
                    loPendingTrans = _iMsAccessDataRepository.GetTableRecords(fileLocation, tableName);
                }
            }
            llTranAmt = loPendingTrans.Count();
            ErrorDetails errorDetails = null;

            // TODO: Handle each records by putting it in try catch
            // process records 
            foreach (PendingTransaction loPendingTran in loPendingTrans)
            {
                errorDetails = new ErrorDetails() { ErrorCode = 0, ErrorDescription = "", IsException = false };
                // add check for blank or null TableUID
                if (loPendingTran.TableUID <= 0)
                {
                    errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "Does not contain valid TableUID",IsException=true };
                }
                else if (viewModel.accessDBTemplateYes) // participation split = true
                {
                    if (!string.IsNullOrEmpty(loPendingTran.ContractCode) & !string.IsNullOrEmpty(loPendingTran.ReinsurerCode))
                    {
                        errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "Contains Contract and Reinsurer Codes",IsException=true };                        
                    }
                    else if (!string.IsNullOrEmpty(loPendingTran.ContractCode))
                    {
                        string proName = "SF_Treaty_Participation_Split";
                        var procParams = ImportPendingManualsSplit(loPendingTran); // Split by Contract Code
                        errorDetails = _importExportRepository.ExecuteProcedure(proName, procParams);                        
                    }
                    else
                    {
                        string proName = "SF_Insert_Transactions";
                        var procParams = ImportPendingManualsTransA(loPendingTran); // With Reinsurer
                        errorDetails = _importExportRepository.ExecuteProcedure(proName, procParams);
                    }
                }
                else if (string.IsNullOrEmpty(loPendingTran.ReinsurerCode.Trim()) & !string.IsNullOrEmpty(loPendingTran.ContractCode.Trim()))
                {
                    errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "Contains Contract and Reinsurer Codes",IsException=true };
                }
                else
                {
                    string proName = "SF_Insert_Transactions";
                    var procParams = ImportPendingManualsTransB(loPendingTran); // With Reinsurer/Contract Code
                    errorDetails = _importExportRepository.ExecuteProcedure(proName, procParams);
                }
                if (errorDetails.IsException)
                {
                    errorDetails = ProcessError(errorDetails);
                    lsErrDesc = errorDetails.ErrorDescription;
                    lsErrDesc = _importExportRepository.GetErrorDescription(lsErrDesc);
                    if (string.IsNullOrEmpty(lsErrDesc)) lsErrDesc = errorDetails.ErrorDescription;
                    _iMsAccessDataRepository.InsertErrorLog(fileLocation, tableName, lsErrDesc, loPendingTran.TableUID.ToString());                    

                }
                else
                {
                    string sql = "UPDATE [" + tableName + "] " + "SET OpenClosedFlag = 'C' " + "WHERE TableUID = " + loPendingTran.TableUID.ToString();
                    _iMsAccessDataRepository.ExecuteQuery(sql, fileLocation);
                    loPendingTran.OpenClosedFlag = "C";
                }
            }
            // count records 
            int completedTransactions = loPendingTrans.Where(pending => pending.OpenClosedFlag == "C").Count();
            int rejectedRecords = llTranAmt - completedTransactions;

            viewModel.processRecord = new ImportMessage();
            viewModel.processRecord.ProcessedRecord = "Total Records Processed..." + llTranAmt.ToString("##,###,##0");
            viewModel.processRecord.AppliedRecord = "Records Applied to Schedule F..." + completedTransactions.ToString("##,###,##0");
            viewModel.processRecord.RejectedRecord = "Records Rejected..." + rejectedRecords.ToString("##,###,##0");
            return viewModel;
        }

        public ImportExportViewModel ImportPendingManuals(ImportExportViewModel viewModel, string tableName, string fileLocation)
        {
            var lsErrDesc = default(string);
            int llTranAmt;
            // Initilize Error Log
            var logTableCreation = _iMsAccessDataRepository.InitializeErrorLog(tableName, fileLocation);
            // Get closeDate 
            var closeDate = _importExportRepository.GetCloseDate();
            //Load table data 
            List<PendingTransaction> loPendingTrans = null;
            List<string> tables = new List<string>();
            if (tableName != null)
            {
                if (tableName.IndexOf(',') > 0)
                    tables = tableName.Split(",").ToList();
                else tables.Add(tableName);
                foreach (string table in tables)
                {
                    loPendingTrans = _iMsAccessDataRepository.GetTableRecords(fileLocation, tableName);
                }
            }
            llTranAmt = loPendingTrans.Count();
            ErrorDetails errorDetails = null;

            // TODO: Handle each records by putting it in try catch
            // process records 
            foreach (PendingTransaction loPendingTran in loPendingTrans)
            {
                errorDetails = new ErrorDetails() { ErrorCode = 0, ErrorDescription = "", IsException = false };
                lbError = false;
                // add check for blank or null TableUID
                if (loPendingTran.TableUID <= 0)
                {
                    errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "Does not contain valid TableUID", IsException = true };
                }

                // add check for invalid TableLoadType
                else if (loPendingTran.TableLoadType.Trim() != "D" && loPendingTran.TableLoadType.Trim() != "T" && loPendingTran.TableLoadType.Trim() != " "
                    && !string.IsNullOrWhiteSpace(loPendingTran.TableLoadType) & !string.IsNullOrEmpty(loPendingTran.TableLoadType.Trim()))
                {
                    errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "TableLoadType not equal to D, T or blank", IsException = true };
                }
                else if (viewModel.accessDBTemplateYes) // split = 'Y'
                {
                    if (!string.IsNullOrEmpty(loPendingTran.ContractCode) && !string.IsNullOrEmpty(loPendingTran.ReinsurerCode))
                    {
                        errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "Contains Contract and Reinsurer Codes", IsException = true };
                    }
                    else if (!string.IsNullOrEmpty(loPendingTran.ContractCode))
                    {
                        string proName = "SF_Treaty_Participation_Split";
                        var procParams = ImportPendingManualsSplit(loPendingTran); // Split by Contract Code
                        errorDetails = _importExportRepository.ExecuteProcedure(proName, procParams);
                    }
                    else
                    {
                        string proName = "SF_Insert_Transactions";
                        var procParams = ImportPendingManualsTransA(loPendingTran); // With Reinsurer
                        errorDetails = _importExportRepository.ExecuteProcedure(proName, procParams);
                    }
                }
                else if (string.IsNullOrEmpty(loPendingTran.ReinsurerCode.Trim()) & !string.IsNullOrEmpty(loPendingTran.ContractCode.Trim()))
                {
                    errorDetails = new ErrorDetails() { ErrorCode = 40002, ErrorDescription = "Contains Contract and Reinsurer Codes", IsException = true };
                }
                else
                {
                    string proName = "SF_Insert_Transactions";
                    var procParams = ImportPendingManualsTransB(loPendingTran); // With Reinsurer/Contract Code
                    errorDetails = _importExportRepository.ExecuteProcedure(proName, procParams);
                }

                if (errorDetails.IsException)
                {
                    errorDetails = ProcessError(errorDetails);
                    lsErrDesc = errorDetails.ErrorDescription;
                    lsErrDesc = _importExportRepository.GetErrorDescription(lsErrDesc);
                    if (string.IsNullOrEmpty(lsErrDesc)) lsErrDesc = errorDetails.ErrorDescription;
                    _iMsAccessDataRepository.InsertErrorLog(fileLocation, tableName, lsErrDesc, loPendingTran.TableUID.ToString());

                }
                else
                {
                    string sql = "UPDATE [" + tableName + "] " + "SET OpenClosedFlag = 'C' " + "WHERE TableUID = " + loPendingTran.TableUID.ToString();
                    _iMsAccessDataRepository.ExecuteQuery(sql, fileLocation);
                    loPendingTran.OpenClosedFlag = "C";
                }
            }
            // count records 
            int completedTransactions = loPendingTrans.Where(pending => pending.OpenClosedFlag == "C").Count();
            int rejectedRecords = llTranAmt - completedTransactions;

            viewModel.processRecord = new ImportMessage();
            viewModel.processRecord.ProcessedRecord = "Total Records Processed... " + llTranAmt.ToString("##,###,##0");
            viewModel.processRecord.AppliedRecord = "Records Applied to Schedule F... " + completedTransactions.ToString("##,###,##0");
            viewModel.processRecord.RejectedRecord = "Records Rejected... " + rejectedRecords.ToString("##,###,##0");
            return viewModel;
        }
        private ErrorDetails ProcessError(ErrorDetails errorDetails)
        {
            if (errorDetails.ErrorCode <= 0 && errorDetails.ErrorTitle == null) return null;            
            var switchExpr = errorDetails.ErrorCode;
            switch (switchExpr)
            {
                case -2147217904:
                    {
                        errorDetails.Exception = "Invalid Pending Table";                        
                        break;
                    }
                case 32755:
                    {
                        errorDetails.Exception = "Cancel Open";
                        break;                        
                    }
                // Canceled Open
                case 40002:
                    {
                        errorDetails.ErrorDescription = GetErrDescription(errorDetails.ErrorDescription);
                        break;
                    }
                case 30010: case 30020: case 30030: case 30040: case 30050: case 30110: case 30120: case 30130: case 30140:
                    {
                        errorDetails.ErrorDescription = GetErrDescription(errorDetails.ErrorDescription);
                        break;
                    }
                default:
                    {
                        // loop through DB exceptio ... Which can be tracked in try catch statement
                        errorDetails.IsException = true;
                        break;
                    }
            }
            return errorDetails;
        }
        private string GetErrDescription(string description)
        {
            if(!string.IsNullOrEmpty(description))
            {
                description = description.Replace("]", "");
            }
            return description;
        }
        private DynamicParameters ImportPendingManualsTransA(PendingTransaction poPendingTran)
        {
            
            var param = new DynamicParameters();            
            //lsSQL = "SF_Insert_Transactions ";
            param.Add("@ReinsurerCode", poPendingTran.ReinsurerCode);
            param.Add("@SourceCode", poPendingTran.SourceCode);
            param.Add("@CompanyCode", poPendingTran.CompanyCode);
            param.Add("@CededAssumedFlag", poPendingTran.CededAssumedFlag);
            param.Add("@DisputedFlag", poPendingTran.DisputedFlag);
            param.Add("@Pre1984Flag", poPendingTran.Pre1984Flag);
            param.Add("@PaidLossCurrentAmt", poPendingTran.PaidLossCurrentAmt);
            param.Add("@PaidLoss1to29Amt", poPendingTran.PaidLoss1to29Amt);
            param.Add("@PaidLoss30to90Amt", poPendingTran.PaidLoss30to90Amt);
            param.Add("@PaidLoss91to120Amt", poPendingTran.PaidLoss91to120Amt);
            param.Add("@PaidLossOver120Amt", poPendingTran.PaidLossOver120Amt);
            param.Add("@PaidLAECurrAmt", poPendingTran.PaidLAECurrAmt);
            param.Add("@PaidLAE1to29Amt", poPendingTran.PaidLAE1to29Amt);
            param.Add("@PaidLAE30to90Amt", poPendingTran.PaidLAE30to90Amt);
            param.Add("@PaidLAE91to120Amt", poPendingTran.PaidLAE91to120Amt);
            param.Add("@PaidLAEOver120Amt", poPendingTran.PaidLAEOver120Amt);
            param.Add("@WrittenPremiumAmt", poPendingTran.WrittenPremiumAmt);
            param.Add("@UnearnedPremiumAmt", poPendingTran.UnearnedPremiumAmt);
            param.Add("@CaseReserveAmt", poPendingTran.CaseReserveAmt);
            param.Add("@CaseLAEReserveAmt", poPendingTran.CaseLAEReserveAmt);
            param.Add("@StatPaidALAEAmt", poPendingTran.StatPaidALAEAmt);
            param.Add("@StatPaidLossAmt", poPendingTran.StatPaidLossAmt);
            param.Add("@CommissionAmt", poPendingTran.CommissionAmt);
            param.Add("@PremiumPayableAmt", poPendingTran.PremiumPayableAmt);
            param.Add("@Prior90DayCashAmt", poPendingTran.Prior90DayCashAmt);
            param.Add("@IBNRLossReserveAmt", poPendingTran.IBNRLossReserveAmt);
            param.Add("@IBNRSuppReserveAmt", poPendingTran.IBNRSuppReserveAmt);
            param.Add("@IBNRLAEReserveAmt", poPendingTran.IBNRLAEReserveAmt);
            param.Add("@FundsOnDepositWReinsAmt", poPendingTran.FundsOnDepositWReinsAmt);
            param.Add("@AssetsPledgedForLOCAmt", poPendingTran.AssetsPledgedForLOCAmt);
            param.Add("@LetterOfCreditAmt", poPendingTran.LetterOfCreditAmt);
            param.Add("@OtherAllowedOffsetAmt", poPendingTran.OtherAllowedOffsetAmt);
            param.Add("@MiscBalanceAmt", poPendingTran.MiscBalanceAmt);
            param.Add("@PendingTransactionUID", null);
            param.Add("@@ProductCode", poPendingTran.Product);
            param.Add("@PsUID", poPendingTran.PsUID);
            param.Add("@ProCedeClaimUID", poPendingTran.ProCedeClaimUID);
            param.Add("@FacultativeCode", poPendingTran.FacultativeCode);
            param.Add("@ClaimFileNumber", poPendingTran.ClaimFileNumber);
            param.Add("@ClaimSuffix", poPendingTran.ClaimSuffix);
            param.Add("@BusinessUnit", poPendingTran.BusinessUnit);
            param.Add("@ClaimProgramCode", poPendingTran.ClaimProgramCode);
            param.Add("@PolicyNumber", poPendingTran.PolicyNumber);
            param.Add("@PRPT", poPendingTran.PRPT);
            param.Add("@MLSL", poPendingTran.MLSL);
            param.Add("@JVNumber", poPendingTran.JVNumber);
            param.Add("@KindOfLoss", poPendingTran.KindOfLoss);
            param.Add("@ClaimTransactionID", poPendingTran.ClaimTransactionID);
            param.Add("@TableSourceCode", poPendingTran.TableSourceCode);
            param.Add("@TableSourceRecID", poPendingTran.TableSourceRecID);
            param.Add("@PeoplesoftSource", poPendingTran.PeoplesoftSource);
            param.Add("@ValidProduct", poPendingTran.ValidProduct);
            param.Add("@ValidReinsurer", poPendingTran.ValidReinsurer);
            param.Add("@ValidContract", poPendingTran.ValidContract);
            param.Add("@TableLoadType", poPendingTran.TableLoadType);
            param.Add("@TableLoadType", poPendingTran.TableLoadType);
            param.Add("@TableUID", poPendingTran.TableUID);
            param.Add("@TransactionUID", poPendingTran.TransactionUID); 
            param.Add("@OpenClosedFlag", poPendingTran.OpenClosedFlag);
            param.Add("@TypeCode", poPendingTran.TypeCode);
            param.Add("@Coverage", poPendingTran.Coverage);
            param.Add("@TreatyFacFlag", poPendingTran.TreatyFacFlag);
            param.Add("@Source", poPendingTran.Source);
            param.Add("@OperId", poPendingTran.OperId);
            param.Add("@Ledger", poPendingTran.Ledger);
            param.Add("@CnaReProductSw", poPendingTran.CnaReProductSw);

            // NICO code changes - Begin
            param.Add("@APFlag", poPendingTran.APFlag);
            param.Add("@NICOOffsetFlag", poPendingTran.NICOOffsetFlag);
            param.Add("@OriginalReinsurerCode", poPendingTran.OriginalReinsurerCode);
            // NICO code changes - End
            // BNR 304485 start
            param.Add("@ContractCodeFAC", poPendingTran.ContractCodeFAC);
            param.Add("@ContractUnderwritingYear", poPendingTran.ContractUnderwritingYear);
            param.Add("@ContractLayerEffectiveDate", poPendingTran.ContractLayerEffectiveDate);
            param.Add("@ContractLayerNumber", poPendingTran.ContractLayerNumber);
            param.Add("@CatastropheCode", poPendingTran.CatastropheCode);
            param.Add("@LocationCodePart6", poPendingTran.LocationCodePart6);
            param.Add("@CollateralDeferralEndDate", poPendingTran.CollateralDeferralEndDate);
            param.Add("@CertifiedRatingEffDt", poPendingTran.CertifiedRatingEffDt);
            param.Add("@CertifiedRecoRatingCd", poPendingTran.CertifiedRecoRatingCd);
            param.Add("@CertifiedPercent", poPendingTran.CertifiedPercent);

            param.Add("@OrigReinsCollateDeferralEndDt", poPendingTran.OrigReinsCollateDeferralEndDt);
            param.Add("@OrigReinsCertifiedRatingEffDt", poPendingTran.OrigReinsCertifiedRatingEffDt);
            param.Add("@OrigReinsCertifiedRecoRatCd", poPendingTran.OrigReinsCertifiedRecoRatingCd);
            param.Add("@OrigReinsCertifiedPercent", poPendingTran.OrigReinsCertifiedPercent);
            param.Add("@MultipleBeneficiaryAmt", poPendingTran.MultipleBeneficiaryAmt);
            // BNR 304485 end
            //lsSQL = lsSQL + MMain.DbStr("Y");
            param.Add("@ManLdInd", 'Y');
            
            return param;
        }
        private DynamicParameters ImportPendingManualsTransB(PendingTransaction poPendingTran)
        {
            var param = new DynamicParameters();
            //lsSQL = "SF_Insert_Transactions ";
            param.Add("@ReinsurerCode", poPendingTran.ReinsurerCode);
            param.Add("@ContractCode", poPendingTran.ContractCode);
            param.Add("@SourceCode", poPendingTran.SourceCode);
            param.Add("@CompanyCode", poPendingTran.CompanyCode);
            param.Add("@CededAssumedFlag", poPendingTran.CededAssumedFlag);
            param.Add("@DisputedFlag", poPendingTran.DisputedFlag);
            param.Add("@Pre1984Flag", poPendingTran.Pre1984Flag);
            param.Add("@PaidLossCurrentAmt", poPendingTran.PaidLossCurrentAmt);
            param.Add("@PaidLoss1to29Amt", poPendingTran.PaidLoss1to29Amt);
            param.Add("@PaidLoss30to90Amt", poPendingTran.PaidLoss30to90Amt);
            param.Add("@PaidLoss91to120Amt", poPendingTran.PaidLoss91to120Amt);
            param.Add("@PaidLossOver120Amt", poPendingTran.PaidLossOver120Amt);
            param.Add("@PaidLAECurrAmt", poPendingTran.PaidLAECurrAmt);
            param.Add("@PaidLAE1to29Amt", poPendingTran.PaidLAE1to29Amt);
            param.Add("@PaidLAE30to90Amt", poPendingTran.PaidLAE30to90Amt);
            param.Add("@PaidLAE91to120Amt", poPendingTran.PaidLAE91to120Amt);
            param.Add("@PaidLAEOver120Amt", poPendingTran.PaidLAEOver120Amt);
            param.Add("@WrittenPremiumAmt", poPendingTran.WrittenPremiumAmt);
            param.Add("@UnearnedPremiumAmt", poPendingTran.UnearnedPremiumAmt);
            param.Add("@CaseReserveAmt", poPendingTran.CaseReserveAmt);
            param.Add("@CaseLAEReserveAmt", poPendingTran.CaseLAEReserveAmt);
            param.Add("@StatPaidALAEAmt", poPendingTran.StatPaidALAEAmt);
            param.Add("@StatPaidLossAmt", poPendingTran.StatPaidLossAmt);
            param.Add("@CommissionAmt", poPendingTran.CommissionAmt);
            param.Add("@PremiumPayableAmt", poPendingTran.PremiumPayableAmt);
            param.Add("@Prior90DayCashAmt", poPendingTran.Prior90DayCashAmt);
            param.Add("@IBNRLossReserveAmt", poPendingTran.IBNRLossReserveAmt);
            param.Add("@IBNRSuppReserveAmt", poPendingTran.IBNRSuppReserveAmt);
            param.Add("@IBNRLAEReserveAmt", poPendingTran.IBNRLAEReserveAmt);
            param.Add("@FundsOnDepositWReinsAmt", poPendingTran.FundsOnDepositWReinsAmt);
            param.Add("@AssetsPledgedForLOCAmt", poPendingTran.AssetsPledgedForLOCAmt);
            param.Add("@LetterOfCreditAmt", poPendingTran.LetterOfCreditAmt);
            param.Add("@OtherAllowedOffsetAmt", poPendingTran.OtherAllowedOffsetAmt);
            param.Add("@MiscBalanceAmt", poPendingTran.MiscBalanceAmt);
            param.Add("@PendingTransactionUID", null);
            param.Add("@@ProductCode", poPendingTran.Product);
            param.Add("@PsUID", poPendingTran.PsUID);
            param.Add("@ProCedeClaimUID", poPendingTran.ProCedeClaimUID);
            param.Add("@FacultativeCode", poPendingTran.FacultativeCode);
            param.Add("@ClaimFileNumber", poPendingTran.ClaimFileNumber);
            param.Add("@ClaimSuffix", poPendingTran.ClaimSuffix);
            param.Add("@BusinessUnit", poPendingTran.BusinessUnit);
            param.Add("@ClaimProgramCode", poPendingTran.ClaimProgramCode);
            param.Add("@PolicyNumber", poPendingTran.PolicyNumber);
            param.Add("@PRPT", poPendingTran.PRPT);
            param.Add("@MLSL", poPendingTran.MLSL);
            param.Add("@JVNumber", poPendingTran.JVNumber);
            param.Add("@KindOfLoss", poPendingTran.KindOfLoss);
            param.Add("@ClaimTransactionID", poPendingTran.ClaimTransactionID);
            param.Add("@TableSourceCode", poPendingTran.TableSourceCode);
            param.Add("@TableSourceRecID", poPendingTran.TableSourceRecID);
            param.Add("@PeoplesoftSource", poPendingTran.PeoplesoftSource);
            param.Add("@ValidProduct", poPendingTran.ValidProduct);
            param.Add("@ValidReinsurer", poPendingTran.ValidReinsurer);
            param.Add("@ValidContract", poPendingTran.ValidContract);            
            param.Add("@TableLoadType", poPendingTran.TableLoadType);
            param.Add("@TableUID", poPendingTran.TableUID);
            param.Add("@TransactionUID", poPendingTran.TransactionUID);
            param.Add("@OpenClosedFlag", poPendingTran.OpenClosedFlag);
            param.Add("@TypeCode", poPendingTran.TypeCode);
            param.Add("@Coverage", poPendingTran.Coverage);
            param.Add("@TreatyFacFlag", poPendingTran.TreatyFacFlag);
            param.Add("@Source", poPendingTran.Source);
            param.Add("@OperId", poPendingTran.OperId);
            param.Add("@Ledger", poPendingTran.Ledger);
            param.Add("@CnaReProductSw", poPendingTran.CnaReProductSw);

            // NICO code changes - Begin
            param.Add("@APFlag", poPendingTran.APFlag);
            param.Add("@NICOOffsetFlag", poPendingTran.NICOOffsetFlag);
            param.Add("@OriginalReinsurerCode", poPendingTran.OriginalReinsurerCode);
            // NICO code changes - End
            // BNR 304485 start
            param.Add("@ContractCodeFAC", poPendingTran.ContractCodeFAC);
            param.Add("@ContractUnderwritingYear", poPendingTran.ContractUnderwritingYear);
            param.Add("@ContractLayerEffectiveDate", poPendingTran.ContractLayerEffectiveDate);
            param.Add("@ContractLayerNumber", poPendingTran.ContractLayerNumber);
            param.Add("@CatastropheCode", poPendingTran.CatastropheCode);
            param.Add("@LocationCodePart6", poPendingTran.LocationCodePart6);
            param.Add("@CollateralDeferralEndDate", poPendingTran.CollateralDeferralEndDate);
            param.Add("@CertifiedRatingEffDt", poPendingTran.CertifiedRatingEffDt);
            param.Add("@CertifiedRecoRatingCd", poPendingTran.CertifiedRecoRatingCd);
            param.Add("@CertifiedPercent", poPendingTran.CertifiedPercent);

            param.Add("@OrigReinsCollateDeferralEndDt", poPendingTran.OrigReinsCollateDeferralEndDt);
            param.Add("@OrigReinsCertifiedRatingEffDt", poPendingTran.OrigReinsCertifiedRatingEffDt);
            param.Add("@OrigReinsCertifiedRecoRatCd", poPendingTran.OrigReinsCertifiedRecoRatingCd);
            param.Add("@OrigReinsCertifiedPercent", poPendingTran.OrigReinsCertifiedPercent);
            param.Add("@MultipleBeneficiaryAmt", poPendingTran.MultipleBeneficiaryAmt);
            // BNR 304485 end
            //lsSQL = lsSQL + MMain.DbStr("Y");
            param.Add("@ManLdInd", 'Y');

            return param;
        }
        private DynamicParameters ImportPendingManualsSplit(PendingTransaction poPendingTran)
        {
            var param = new DynamicParameters();
            //lsSQL = "SF_Insert_Transactions ";
            param.Add("@contract", poPendingTran.ContractCode);
            param.Add("@source", poPendingTran.SourceCode);
            param.Add("@company", poPendingTran.CompanyCode);
            param.Add("@caflag", poPendingTran.CededAssumedFlag);
            param.Add("@disputed", poPendingTran.DisputedFlag);
            param.Add("@pre84flag", poPendingTran.Pre1984Flag);
            param.Add("@pdlosscurrent", poPendingTran.PaidLossCurrentAmt);
            param.Add("@pdloss1to29", poPendingTran.PaidLoss1to29Amt);
            param.Add("@pdloss30to90", poPendingTran.PaidLoss30to90Amt);
            param.Add("@pdloss91to120", poPendingTran.PaidLoss91to120Amt);
            param.Add("@pdlossover120", poPendingTran.PaidLossOver120Amt);
            param.Add("@pdlaecurrent", poPendingTran.PaidLAECurrAmt);
            param.Add("@pdlae1to29", poPendingTran.PaidLAE1to29Amt);
            param.Add("@pdlae30to90", poPendingTran.PaidLAE30to90Amt);
            param.Add("@pdlae91to120", poPendingTran.PaidLAE91to120Amt);
            param.Add("@pdlaeover120", poPendingTran.PaidLAEOver120Amt);
            param.Add("@writtenprem", poPendingTran.WrittenPremiumAmt);
            param.Add("@unearnedprem", poPendingTran.UnearnedPremiumAmt);
            param.Add("@caseresv", poPendingTran.CaseReserveAmt);
            param.Add("@caselaeresv", poPendingTran.CaseLAEReserveAmt);
            param.Add("@commission", poPendingTran.CommissionAmt);
            param.Add("@prempay", poPendingTran.PremiumPayableAmt);
            param.Add("@priorcash", poPendingTran.Prior90DayCashAmt);
            param.Add("@ibnrloss", poPendingTran.IBNRLossReserveAmt);
            param.Add("@ibnrsupp", poPendingTran.IBNRSuppReserveAmt);
            param.Add("@ibnrlae", poPendingTran.IBNRLAEReserveAmt);
            param.Add("@fundsheld", poPendingTran.FundsOnDepositWReinsAmt);
            param.Add("@assetspledged", poPendingTran.AssetsPledgedForLOCAmt);
            param.Add("@loc", poPendingTran.LetterOfCreditAmt);
            param.Add("@otheroffsets", poPendingTran.OtherAllowedOffsetAmt);
            param.Add("@miscbal", poPendingTran.MiscBalanceAmt);
            param.Add("@pendtranuid", DBNull.Value);
            param.Add("@productcode", poPendingTran.Product);
            param.Add("@StatPaidALAEAmt", poPendingTran.StatPaidALAEAmt);
            param.Add("@StatPaidLossAmt", poPendingTran.StatPaidLossAmt);
            param.Add("@PsUID", poPendingTran.PsUID);
            param.Add("@claimtransactionid", poPendingTran.ClaimTransactionID);
            param.Add("@polnum", poPendingTran.PolicyNumber);
            param.Add("@tblsrcrecid", poPendingTran.TableSourceRecID);
            param.Add("@psoftsrc", poPendingTran.PeoplesoftSource);
            param.Add("@tblsrccd", poPendingTran.TableSourceCode);
            param.Add("@coverage", poPendingTran.Coverage);
            param.Add("@treatyfacflag", poPendingTran.TreatyFacFlag);
            param.Add("@src", poPendingTran.Source);
            param.Add("@operid", poPendingTran.OperId);
            param.Add("@ledger", poPendingTran.Ledger);
            param.Add("@cnareproductsw", poPendingTran.CnaReProductSw);
            param.Add("@transactionuid", poPendingTran.TransactionUID);
            param.Add("@openclosedflag", poPendingTran.OpenClosedFlag);
            param.Add("@typecode", poPendingTran.TypeCode);
            param.Add("@procedeclaimuid", poPendingTran.ProCedeClaimUID);
            param.Add("@facultativecode", poPendingTran.FacultativeCode);
            param.Add("@claimfilenumber", poPendingTran.ClaimFileNumber);
            param.Add("@claimsuffix", poPendingTran.ClaimSuffix);
            param.Add("@businessunit", poPendingTran.BusinessUnit);
            param.Add("@claimprogramcode", poPendingTran.ClaimProgramCode);
            param.Add("@prpt", poPendingTran.PRPT);
            param.Add("@mlsl", poPendingTran.MLSL);
            param.Add("@jvnumber", poPendingTran.JVNumber);
            param.Add("@kindofloss", poPendingTran.KindOfLoss);
            param.Add("@validprod", poPendingTran.ValidProduct);
            param.Add("@validreco", poPendingTran.ValidReinsurer);
            param.Add("@validcntrct", poPendingTran.ValidContract);
            param.Add("@tblloadtyp", poPendingTran.TableLoadType);
            param.Add("@APFlag", poPendingTran.APFlag);
            param.Add("@NICOOffsetFlag", poPendingTran.NICOOffsetFlag);
            param.Add("@OriginalReinsurerCode", poPendingTran.OriginalReinsurerCode);
            param.Add("@ContractCodeFAC", poPendingTran.ContractCodeFAC);
            param.Add("@ContractUnderwritingYear", poPendingTran.ContractUnderwritingYear);
            param.Add("@ContractLayerEffectiveDate", poPendingTran.ContractLayerEffectiveDate);
            param.Add("@ContractLayerNumber", poPendingTran.ContractLayerNumber);
            param.Add("@CatastropheCode", poPendingTran.CatastropheCode);
            param.Add("@LocationCodePart6", poPendingTran.LocationCodePart6);
            param.Add("@CollateralDeferralEndDate", poPendingTran.CollateralDeferralEndDate);
            param.Add("@CertifiedRatingEffDt", poPendingTran.CertifiedRatingEffDt);
            param.Add("@CertifiedRecoRatingCd", poPendingTran.CertifiedRecoRatingCd);
            param.Add("@CertifiedPercent", poPendingTran.CertifiedPercent);
            param.Add("@OrigReinsCollateDeferralEndDt", poPendingTran.OrigReinsCollateDeferralEndDt);
            param.Add("@OrigReinsCertifiedRatingEffDt", poPendingTran.OrigReinsCertifiedRatingEffDt);
            param.Add("@OrigReinsCertifiedRecoRatCd", poPendingTran.OrigReinsCertifiedRecoRatingCd);
            param.Add("@OrigReinsCertifiedPercent", poPendingTran.OrigReinsCertifiedPercent);
            param.Add("@MultipleBeneficiaryAmt", poPendingTran.MultipleBeneficiaryAmt);
            param.Add("@Reinsurercodee", poPendingTran.ReinsurerCode);
            param.Add("@tableuid", poPendingTran.TableUID);
            param.Add("@ManLdInd", 'Y');
            return param;

        }


    }
}