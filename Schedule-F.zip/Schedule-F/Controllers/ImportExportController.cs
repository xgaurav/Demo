﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Schedule_F.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using DataAccess.MsAccess;
using Microsoft.AspNetCore.Mvc.Rendering;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Schedule_F.Common;
using EntiryModel;
using System.IO.IsolatedStorage;

namespace Schedule_F.Controllers
{
    public class ImportExportController : Controller
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly ILogger<ImportExportController> _logger;
        private readonly IImportExportRepository _importExportRepository;
        private readonly IMsAccessDataRepository _iMsAccessDataRepository;
        private readonly IConfiguration _configuration;
        public ImportExportController(IConfiguration configuration, IWebHostEnvironment host, ILogger<ImportExportController> logger, IImportExportRepository importExportRepository, IMsAccessDataRepository iMsAccessDataRepository)
        {
            _hostEnvironment = host;
            _logger = logger;
            _importExportRepository = importExportRepository;
            _iMsAccessDataRepository = iMsAccessDataRepository;
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            ImportExportViewModel viewModel = new ImportExportViewModel();
            var companyDetails = _importExportRepository.GetCompanyGroup();
            viewModel.CompanyDetails = viewModel.GetCompanyList(companyDetails);
            return View(viewModel);
        }

        [HttpPost("UploadFile")]
        public async Task<IActionResult> UploadFile(ImportExportViewModel viewModel)
        {
            List<SelectListItem> Tables = new List<SelectListItem>();
            var allowedExtensions = new[] { ".mdb", ".accdb" }.ToList();
            IFormFile fileUpload = viewModel.fileUpload;
            viewModel.Message = string.Empty;
            viewModel.Tables = Tables;
            try
            {
                if (fileUpload == null || fileUpload.Length == 0)
                {
                    viewModel.Message = "File has not Uploaded or the file is empty";                    
                    return PartialView("TableList", viewModel);
                }
                var extension = Path.GetExtension(fileUpload.FileName);
                if (!allowedExtensions.Contains(extension))
                {
                    viewModel.Message = "Uploaded file type is not valid database file. Please upload valid file type.";                   
                    return PartialView("TableList", viewModel);
                }
                // check file type
                string directoryPath = $"{_hostEnvironment.WebRootPath}/uploads/";
                string filePath = Path.Combine(directoryPath, fileUpload.FileName);
                // full path to file in temp location
                if (System.IO.File.Exists(filePath)) System.IO.File.Delete(filePath);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await fileUpload.CopyToAsync(stream);
                }
                // read access database
               // string logDbConnectionString = _configuration.GetValue<string>("MsAccessConnectionString");                
                var listOfTables = _iMsAccessDataRepository.GetTableName(filePath);
                // check if not table's found
                if(listOfTables.Count() ==0)
                {
                    viewModel.Message = "No database tables found in uploaded file. Please chose database with valid tables.";
                    return PartialView("TableList", viewModel);
                }

                foreach (string list in listOfTables)
                {
                    Tables.Add(new SelectListItem { Text = list, Value = list });
                }                
                viewModel.fileName = fileUpload.FileName;
                viewModel.Tables = Tables;
            }
            catch (Exception ex)
            {
                viewModel.errorDetails = new ErrorDetails() { IsException = true, Exception = ex.Message, ErrorDescription = ex.Message };
                _logger.LogError("Exception Details : ", ex.Message);
                throw ex;
            }
            //Don't rely on or trust the FileName property without validation.
            return PartialView("TableList", viewModel);
        }

        [HttpPost("ImportToDatabase")]
        public IActionResult ImportToDatabase(ImportExportViewModel viewModel)
        {
            IFormFile fileUpload = viewModel.fileUpload;
            try
            {
                if (fileUpload != null)
                {
                    string directoryPath = $"{_hostEnvironment.WebRootPath}/uploads/";
                    string filePath = Path.Combine(directoryPath, fileUpload.FileName);
                    // full path to file in temp location
                    if (System.IO.File.Exists(filePath))
                    {
                        ImportPendingTransaction transaction = new ImportPendingTransaction(_importExportRepository, _iMsAccessDataRepository);
                        transaction.Import(viewModel, viewModel.SelectedTable, filePath);
                        // Delete file if all process
                        //System.IO.File.Delete(filePath);
                    }
                    viewModel.Tables = null;
                }
            }
            catch (Exception ex)
            {
                viewModel.errorDetails = new ErrorDetails() {IsException=true,Exception = ex.Message, ErrorDescription = ex.Message };
                _logger.LogError("Exception Details : ", ex.Message);
            }
            return PartialView("ModelPopup", viewModel);
        }
    }
}

