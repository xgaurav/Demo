﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataAccess;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Schedule_F.Models;

namespace Schedule_F.Views.Home
{
    public class ContactController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly ILogger<ContactController> _logger;
        private readonly IReinsurerRepository _reinsurerRepository;
        

        public ContactController(ILogger<ContactController> logger, IConfiguration configuration, IWebHostEnvironment hostEnvironment, IReinsurerRepository reinsurerRepository)
        {
            _configuration = configuration;
            _logger = logger;
            _hostEnvironment = hostEnvironment;
            _reinsurerRepository = reinsurerRepository;
        }
        public IActionResult Index()
        {
            ContactViewModel viewModel = new ContactViewModel();
            return View(viewModel);
        }
        //TODO: Implement this using the partial view 
        [HttpPost]
        public IActionResult Search(string searchName, string searchCode, string search, string newbutton)
        {
            ContactViewModel viewModel = new ContactViewModel();
            try
            {
                if (!string.IsNullOrEmpty(newbutton))
                {
                    viewModel.ReinsurerCode = string.Empty;
                    return View("Index", viewModel);
                }
                if (string.IsNullOrEmpty(searchName))
                {
                    ModelState.AddModelError(nameof(viewModel.ReinsurerCode), "Minimum 3 characters required for name.");
                    return View("Index", viewModel);
                }               
                else if (!string.IsNullOrEmpty(searchName) && searchName.Length < 3)
                {
                    ModelState.AddModelError(nameof(viewModel.ReinsurerCode), "The search name should not be at least 3 characters");
                    return View("Index", viewModel);
                }
                else
                {
                    // check for not Implementated LookIn functionality
                    string searchCodeResult = viewModel.GetLookInCode(Convert.ToInt16(searchCode));
                    if (string.IsNullOrEmpty(searchCodeResult))
                    {
                        ModelState.AddModelError(nameof(viewModel.ReinsurerCode), "The selected LookIn search option is not implementated in this scope.");
                        return View("Index", viewModel);
                    }
                    viewModel.MyItem = searchCode;
                    string logDbConnectionString = _configuration.GetConnectionString("Dev");
                    //IReinsurerRepository reinsurerRepository = new ReinsurerRepository(logDbConnectionString);
                    var result = _reinsurerRepository.Get(searchName, searchCodeResult);
                    viewModel.ReinsurerCode = searchName;
                    viewModel.Reinsurer = result.ToList();
                    if (viewModel.Reinsurer == null || viewModel.Reinsurer.Count == 0)
                        viewModel.NoRecordMessage = "No Records found for the specified search parameters. Please check search parameters and try again.";
                    return View("Index", viewModel);
                }
            }
            catch (Exception ex)
            {
                //viewModel.errorDetails = new ErrorDetails() { IsException = true, Exception = ex.Message, ErrorDescription = ex.Message };
                _logger.LogError("Exception Details : ", ex.Message);
            }
            return View("Index", viewModel);
        }
       
    }
}
