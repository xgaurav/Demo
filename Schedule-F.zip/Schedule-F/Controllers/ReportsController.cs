﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Schedule_F.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using EntiryModel;
using DataAccess;

using Microsoft.Extensions.Configuration;



namespace Schedule_F.Controllers
{
    public class ReportsController : Controller
    {
        private readonly IConfiguration _configuration;

        public ReportsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET: ReportsController
        public ActionResult Index()
        {
            return RedirectToAction("Reports");

           // return Reports();
        }
     
        [HttpPost]
        public ActionResult GetReportsList(string cateGoryId)
        {

            string logDbConnectionString = _configuration.GetConnectionString("Dev");
            ICategoryRepository categoryRepository = new CategoryRepository(logDbConnectionString);

            //call the stored procedure to fill the data
            var result = categoryRepository.GetReportsList(cateGoryId); //Category

            ReportsViewModel viewModel = new ReportsViewModel();

            viewModel.rptName = viewModel.rptNameLst(result);
           // viewModel.Category = viewModel.rptName= viewModel.rptNameLst(result);

            return Json(viewModel.rptName);

        }
        public ActionResult Reports()
        {
            string logDbConnectionString = _configuration.GetConnectionString("Dev");

            ICategoryRepository categoryRepository = new CategoryRepository(logDbConnectionString);
            ICompanyRepository companyRepository = new CompanyRepository(logDbConnectionString);
            IFinancialStatusRepository financialStatusRepository = new FinancialStatusRepository(logDbConnectionString);
            ILocationRepository locationRepository = new LocationRepository(logDbConnectionString);

            var result = categoryRepository.GetRptCategory(); //Category
            var cmpLst = companyRepository.GetCompany();
            var finStatus = financialStatusRepository.GetFinancialStatus();
            var loc = locationRepository.GetLocation();

            ReportsViewModel viewModel = new ReportsViewModel();

            viewModel.Category = viewModel.lstCategory(result);

            viewModel.Company = viewModel.lstCompany(cmpLst);

            viewModel.finStatus = viewModel.lstfinStatus(finStatus);

            viewModel.location = viewModel.lstLocation(loc);

            viewModel.rptName = new List<SelectListItem>();
            // viewModel.rptName = viewModel.lstCategory(result);



            ViewBag.lstval = viewModel.lstCategory(result);
            return View("Reports", viewModel);

            //IReinsurerRepository reinsurerRepository = new ReinsurerRepository(logDbConnectionString);
            //var result = reinsurerRepository.Get(searchName, searchCodeResult);
            //viewModel.ReinsurerCode = searchName;
            //viewModel.Reinsurer = result.ToList();
            ////fetch Drop down data
            //ReportsViewModel viewModel1 = new ReportsViewModel();
            //viewModel1.Category = 

            //string searchName = string.Empty;
            //string newbutton =string.Empty;
            //string searchCode = string.Empty;


            //ContactViewModel viewModel = new ContactViewModel();
            //if (string.IsNullOrEmpty(searchName))
            //{
            //    ModelState.AddModelError(nameof(viewModel.ReinsurerCode), "Please enter 3 characters in name");

            //    return View("Index", viewModel);
            //}

            //else if (!string.IsNullOrEmpty(newbutton))
            //{
            //    viewModel.ReinsurerCode = string.Empty;
            //    return View("Index", viewModel);
            //}

            //else
            //{

            //    string searchCodeResult = viewModel.GetLookInCode(Convert.ToInt16(searchCode));
            //    if (string.IsNullOrEmpty(searchCodeResult))
            //    {
            //        ModelState.AddModelError(nameof(viewModel.ReinsurerCode), "The selected LookIn search option is not implementated in this scope.");
            //        return View("Index", viewModel);
            //    }

            //viewModel.MyItem = searchCode;

            //return View();
            //}
        }

        [HttpPost]
        public ActionResult GetReportsCriteria(string reportID)
        { 
            
            string logDbConnectionString = _configuration.GetConnectionString("Dev");
            IReportCriteriaRepository reportCriteriaRepository = new ReportCriteriaRepository(logDbConnectionString);

            //call the stored procedure to fill the data
            var result = reportCriteriaRepository.GetReportCriteria(reportID); //Category
            ReportsViewModel reportsViewModel = new ReportsViewModel();
            var val = reportsViewModel.LstReportCriteria(result);

            return Json(reportCriteriaRepository.GetReportCriteria(reportID));
        }

       // [HttpGet]
        public  IActionResult ExportExcel()
        {
            
             string logDbConnectionString = _configuration.GetConnectionString("Dev");
            IReportCriteriaRepository reportCriteriaRepository = new ReportCriteriaRepository(logDbConnectionString);
            var dataResult = reportCriteriaRepository.GetExcelFourReport(null, null, "E");
            //fist create a object of the class            
            

            List<Excel_Part_4> resultLst = new List<Excel_Part_4>();
            foreach (var item in dataResult)
            {
                resultLst.Add(item);
            }

            var resultExceldata = ExcelHelper.ExportToExcel<Excel_Part_4>(resultLst);


            var fileContentResult = new FileContentResult(resultExceldata, "application/ms-excel")
            {
                FileDownloadName = "Excel_Part_4.xls"
            };





            return fileContentResult;

        }




        // GET: ReportsController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ReportsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ReportsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportsController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ReportsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportsController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ReportsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
