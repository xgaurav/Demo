using DataAccess;
using DataAccess.MsAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;

namespace UnitTest.DataAccess
{
    [TestClass]
    public class UnitTest_ImportExport
    {
        private readonly string connectionString;

        public UnitTest_ImportExport()
        {
            connectionString = @"Server=.\SQLExpress;Database = ScheduleF; Trusted_Connection = True; MultipleActiveResultSets = true";
        }
        [TestMethod]
        public void GetCompanyInformation()
        {

            IImportExportRepository importExportRepository = new ImportExportRepository(connectionString);
            var result = importExportRepository.GetCompanyGroup();
            Assert.IsTrue(result != null);
        }

        [TestMethod]
        public void GetCloseDate()
        {

            IImportExportRepository importExportRepository = new ImportExportRepository(connectionString);
            var result = importExportRepository.GetCloseDate();
            Assert.IsTrue(result != null);
        }
        //[TestMethod]
        //public void TestTableCreation()
        //{
        //    var connectionString = "Driver ={ Microsoft Access Driver(*.mdb, *.accdb)}; DBQ = ";
        //    IMsAccessDataRepository importExportRepository = new MsAccessDataRepository(connectionString);
        //    string fileLocation = @" C:\Users\CAE7093\Source\Repos\Schedule - F\wwwroot / uploads / Manual Upload Q4.mdb";

        //    List<string> tableName = new List<string>();
        //    tableName.Add("1015_Manual Template Q2 2019-Revised_WORKING");
        //    var result = importExportRepository.GetTablesRecords(fileLocation, tableName);


        //    Assert.IsTrue(result != null);
        //}
        //[TestMethod]
        //public void GetTableDate()
        //{
        //    var connectionString = "Driver ={ Microsoft Access Driver(*.mdb, *.accdb)}; DBQ = ";
        //    IMsAccessDataRepository importExportRepository = new MsAccessDataRepository(connectionString);
        //    string fileLocation = @" C:\Users\CAE7093\Source\Repos\Schedule - F\wwwroot / uploads / Manual Upload Q4.mdb";
            
        //    List<string> tableName = new List<string>();
        //    tableName.Add("1015_Manual Template Q2 2019-Revised_WORKING");
        //    var result = importExportRepository.GetTablesRecords(fileLocation, tableName);


        //    Assert.IsTrue(result != null);
        //}
       
    }
}
