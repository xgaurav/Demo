using DataAccess;
using DataAccess.MsAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest.DataAccess
{
    [TestClass]
    public class UnitTest_Reinsurer
    {
        [TestMethod]
        public void TestMethod1()
        {
            var connectionString = @"Server=.\SQLExpress;Database = Schedule-F; Trusted_Connection = True; MultipleActiveResultSets = true";
            IReinsurerRepository reinsurerRepository = new ReinsurerRepository(connectionString);
            var result = reinsurerRepository.Get("1", "code");
            Assert.IsTrue(result != null);

        }

        [TestMethod]
        public void TestMethod_MsAccess()
        {
            var accessDbDal = new MsAccessDataRepository(string.Empty);
            
            var listOfTables = accessDbDal.GetTableName(string.Empty);
            
            Assert.IsTrue(listOfTables.Count > 0);

        }
    }
}
